package example.com.adviceretro

import Quote
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.lifecycle.Observer
import example.com.weatherapp.data.api.ApiHelper
import example.com.weatherapp.data.api.RetrofitBuilder
import androidx.lifecycle.*
import android.content.Intent
import android.widget.TextView

import androidx.lifecycle.*


class MainActivity : AppCompatActivity() {
    lateinit var view: TextView
    private lateinit var mainViewModel: MainViewModel
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        setupViewModel()
        setupObserver()

    }


    private fun setupObserver() {
        mainViewModel.getQuotes().observe(this, Observer {
            when (it.status) {
                Status.SUCCESS -> {


                    it.data?.let { quote -> renderQuote(quote)}

                }

                Status.ERROR -> {
                    //Handle Error

                    Toast.makeText(this, it.message, Toast.LENGTH_LONG).show()
                }
            }
        })
    }
    private fun setupViewModel() {
        mainViewModel = ViewModelProvider(
            this,
            ViewModelFactory(ApiHelper(RetrofitBuilder.apiService))
        ).get(MainViewModel::class.java)
    }

    private fun renderQuote(quote: Quote) {
        view=findViewById(R.id.textViewQuote)
            view.text=quote.slip.advice

    }
}