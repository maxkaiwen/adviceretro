package example.com.weatherapp.data.api
import Quote


import retrofit2.http.GET
private const val id:String="1"
//private const val apiWe:String="group?id=524901,703448,2643743&appid="

interface ApiService {
    @GET(id)
   suspend fun getQuote(): Quote
}