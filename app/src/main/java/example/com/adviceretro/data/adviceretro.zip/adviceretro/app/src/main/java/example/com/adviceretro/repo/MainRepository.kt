package example.com.adviceretro.repo

import example.com.weatherapp.data.api.ApiHelper

class MainRepository(private val apiHelper: ApiHelper) {
    suspend fun  getQuote()=apiHelper.getQuote()
}