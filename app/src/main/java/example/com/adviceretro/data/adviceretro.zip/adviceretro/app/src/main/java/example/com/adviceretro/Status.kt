package example.com.adviceretro

enum class Status {
    SUCCESS,
    ERROR,
    LOADING
}